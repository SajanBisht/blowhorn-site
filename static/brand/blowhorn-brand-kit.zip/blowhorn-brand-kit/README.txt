BLOWHORN BRAND KIT
==================

Everything you need to show Blowhorn: the logo, colors, type, the usage
rules, Major Blowhorn, the troops and Old Thunderlung. Version 1, October
2026. The guidelines, with examples, also live at https://blowhorn.ai/brand/

Only want the logo? Get the logo kit at
https://blowhorn.ai/brand/blowhorn-logo-kit.zip


WHAT'S INSIDE

  Blowhorn-brand-guidelines.pdf   The guidelines, seven slides
  logo/                           Lockups, icons, wordmarks, app icons and
                                  favicons, SVG and PNG, light and dark
  colors/                         The palette as JSON, CSS and plain text
  cast/                           Major Blowhorn, Old Thunderlung and the
                                  troops, one folder per character

Logos come as SVG (svg/, the master: use it when you can) and as
transparent PNG in several sizes (png/, named <file>-<width>.png).
Files ending in -on-dark or -white are for dark grounds.


THE CAST

  cast/major-blowhorn/           Major Blowhorn, 30 pictures (with cutouts/)
  cast/old-thunderlung/          Old Thunderlung, 19 pictures (with icons/)
  cast/chief-drill-instructor/   Chief Drill Instructor, 4 pictures
  cast/corporal-clover/          Corporal Clover, 1 picture
  cast/general/                  The General, 5 pictures (with cutouts/)
  cast/gi-donkey/                GI Donkey, 6 pictures
  cast/keyboard-warrior/         Keyboard Warrior, 5 pictures (with cutouts/)
  cast/mouse-marine/             Mouse Marine, 5 pictures (with cutouts/)
  cast/platoon-private/          Platoon Private, 4 pictures
  cast/recruit-chick/            Recruit Chick, 9 pictures
  cast/robo-recruit/             Robo-Recruit, 5 pictures (with cutouts/)
  cast/sergeant-steady/          Sergeant Steady, 1 picture
  cast/sleeper-cell/             Sleeper Cell, 5 pictures (with cutouts/)
  cast/staff-sergeant-red-flag/  Staff Sergeant Red Flag, 1 picture
  cast/trench-trooper/           Trench Trooper, 5 pictures (with cutouts/)

Each picture is here once, at full size. Most are drawn on a black stage,
and the files in cutouts/ have a transparent ground for every other
ground. Old Thunderlung comes with its red cord and tassels ("tassel",
the usual look) and plain ("notassel"), with ready-made square icons in
icons/.


USING THE LOGO

  Light grounds: blowhorn-lockup-horizontal.svg. Dark grounds: the
  -on-dark file. Teal, photos or anything busy: -mono-charcoal on light,
  -mono-white on dark. Square spaces: the stacked lockup. Where the name is
  already there: the icon.

  Keep clear space of half the icon's height on every side. Smallest
  sizes: horizontal lockup 96 px wide, stacked 64 px, icon 24 px. Below
  24 px, use the favicon files.

  Please don't recolor, outline, stretch, squash or rotate the logo, add
  shadows, glows or gradients, put the full-color icon on teal, retype the
  wordmark in a font, or rearrange the icon and the wordmark. If it isn't
  in this kit, it isn't the logo.


USING THE COLORS

  Lead with teal and charcoal. Yellow is an accent: under a tenth of any
  layout. For text on light grounds use Teal Deep, not Teal. Text on teal
  or yellow is Near Black, never white. Hex and RGB values are in colors/.


USING THE TYPE

  Display: Bricolage Grotesque, ExtraBold, tight tracking.
  Text: Instrument Sans, 400 to 600.
  Code and labels: JetBrains Mono, 400 and 500.

  All three are free from Google Fonts, under the SIL Open Font License:
  https://fonts.google.com/specimen/Bricolage+Grotesque
  https://fonts.google.com/specimen/Instrument+Sans
  https://fonts.google.com/specimen/JetBrains+Mono
  The logo files don't need any font: every letter is outlined.


USING THE CAST

  One character per page or screen, and one appearance of Major per page.
  Use the pictures as they are, on their black stage or as cutouts.
  Put Major on white, light teal or cream grounds. On bare teal give him a
  cream or yellow disc; on near black, keep his cream keyline.
  Don't recolor, outline, add shadows or texture, rotate, or crop through a
  character.
  Keep the cast away from anything about security, sign-in, billing, legal
  matters or a failed post. Major takes those personally.
  Old Thunderlung is Major's family bugle, not his megaphone. Use the plain
  version where the cord and tassels would be too small or too busy.


THE NAME

  Blowhorn. One word, capital B. In formal copy say Layer5 Blowhorn the
  first time, then Blowhorn. Not BlowHorn, not Blow Horn.


LICENSE

  Blowhorn, the Blowhorn logos, Major Blowhorn, Old Thunderlung and the
  troops are marks and artwork of Layer5, Inc. This kit lets you write
  about Blowhorn and show it as it is, for press, reviews, talks, events
  and partner pages. It doesn't grant a license to use the marks or the
  characters in your own product names, logos, merchandise or ads.

Questions: https://blowhorn.ai/brand/
