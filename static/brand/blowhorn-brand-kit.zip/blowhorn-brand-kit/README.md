# Blowhorn brand kit

The Blowhorn logo, wordmark, colors and mascot, ready to use. The full
guidelines, with examples, live at https://blowhorn.ai/brand/

Version 1, October 2026.

## What's inside

| Folder | Holds |
| --- | --- |
| `logo/lockup/` | The horizontal and stacked lockups, the one-color lockups and the Layer5 Blowhorn lockup |
| `logo/icon/` | The Crowhorn icon on its own, full color and one color |
| `logo/wordmark/` | The wordmark on its own |
| `logo/app-icon/` | App icon tiles |
| `logo/favicon/` | Favicons drawn for 16 and 32 pixels, and the iOS touch icon |
| `mascot/` | Major Blowhorn |
| `colors/` | The palette as JSON, CSS custom properties and plain text |
| `Blowhorn-brand-guidelines.pdf` | The guidelines page, printed |

Every asset comes as SVG (`svg/`, the master, use it when you can) and as
transparent PNG in several sizes (`png/`, named `<file>-<width>.png`).

## Which file

| On | Use |
| --- | --- |
| White, light or cream grounds | `blowhorn-lockup-horizontal.svg` |
| Near black or charcoal grounds | `blowhorn-lockup-horizontal-on-dark.svg` |
| Square spaces | `blowhorn-lockup-stacked.svg`, `blowhorn-lockup-stacked-on-dark.svg` |
| Teal, photos or anything busy | `-mono-charcoal` on light, `-mono-white` on dark |
| Where the name is already there | `blowhorn-icon.svg`, `blowhorn-icon-on-dark.svg` |
| Alongside Layer5 | `layer5-blowhorn-lockup.svg`, `layer5-blowhorn-lockup-on-dark.svg` |

`blowhorn-wordmark-white.svg` is the wordmark for dark grounds.

## Clear space and minimum size

- Keep clear space of half the icon's height on every side.
- Horizontal lockup: at least 96 px wide. Stacked lockup: 64 px. Icon: 24 px.
- Below 24 px, use the favicon files. They are drawn for that size, not shrunk.

## Colors

| Name | Hex | RGB |
| --- | --- | --- |
| Teal | #00B39F | 0, 179, 159 |
| Charcoal | #3C494F | 60, 73, 79 |
| Near Black | #1E2117 | 30, 33, 23 |
| White | #FFFFFF | 255, 255, 255 |
| Teal Bright | #00D3A9 | 0, 211, 169 |
| Teal Deep | #00756A | 0, 117, 106 |
| Yellow | #EBC017 | 235, 192, 23 |
| Coral | #EE5A44 | 238, 90, 68 |
| Cream | #FFF6E0 | 255, 246, 224 |

Lead with teal and charcoal. Yellow is an accent: under a tenth of any layout.
Coral belongs to the rooster. For text on light grounds use Teal Deep, not
Teal. Text on teal or yellow is Near Black, never white. The illustration
colors and the light and dark theme values are in `colors/`.

## Type

- Display: Bricolage Grotesque, ExtraBold, tight tracking. https://fonts.google.com/specimen/Bricolage+Grotesque
- Text: Instrument Sans, 400 to 600. https://fonts.google.com/specimen/Instrument+Sans
- Code and labels: JetBrains Mono, 400 and 500. https://fonts.google.com/specimen/JetBrains+Mono

All three are free under the SIL Open Font License. The logo files don't need
them: every letter is outlined.

## The name

Blowhorn. One word, capital B. In formal copy say Layer5 Blowhorn the first
time, then Blowhorn. Not BlowHorn, not Blow Horn.

## Please don't

- Recolor, outline, stretch, squash or rotate the logo
- Add shadows, glows, gradients or other effects
- Put the full-color icon on teal, or any logo on a busy or low-contrast ground
- Retype the wordmark in a font. Place the file
- Rearrange the icon and wordmark, or pull the comb off the horn
- Use retired marks or the product's former name. If it isn't in this kit, it isn't the logo
- Put Major Blowhorn on bare teal (give him a cream or yellow disc), or on near black without his cream keyline

## Major Blowhorn

Major Blowhorn is part of the brand. Use him on white, light teal or cream
grounds, one appearance per page, and keep him out of anything about security,
billing or legal matters. He takes those personally.

## Questions

https://blowhorn.ai/brand/

Blowhorn and the Blowhorn logos are marks of Layer5, Inc. This kit lets you
refer to Blowhorn; it doesn't grant a license to use the marks in your own
product names or logos.
