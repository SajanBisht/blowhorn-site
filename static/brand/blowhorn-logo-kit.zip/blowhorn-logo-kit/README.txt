BLOWHORN LOGO KIT
=================

The Blowhorn logo, icon and wordmark, ready to use. Version 1, October 2026.
The full brand kit (colors, type, usage rules, Major Blowhorn and the troops)
and the guidelines live at https://blowhorn.ai/brand/


WHAT'S INSIDE

  logo/lockup/     Horizontal and stacked lockups, one-color lockups,
                   and the Layer5 Blowhorn lockup
  logo/icon/       The Crowhorn icon on its own, full color and one color
  logo/wordmark/   The wordmark on its own
  logo/app-icon/   App icon tiles
  logo/favicon/    Favicons drawn for 16 and 32 pixels, and the touch icon

Every logo comes as SVG (svg/, the master: use it when you can) and as
transparent PNG in several sizes (png/, named <file>-<width>.png).
Files ending in -on-dark or -white are for dark grounds.


WHICH FILE

  White, light or cream grounds   blowhorn-lockup-horizontal.svg
  Near black or charcoal grounds  blowhorn-lockup-horizontal-on-dark.svg
  Square spaces                   blowhorn-lockup-stacked.svg (or -on-dark)
  Teal, photos, anything busy     -mono-charcoal on light, -mono-white on dark
  Where the name is already there blowhorn-icon.svg (or -on-dark)
  Alongside Layer5                layer5-blowhorn-lockup.svg (or -on-dark)


CLEAR SPACE AND SIZE

  Keep clear space of half the icon's height on every side.
  Smallest sizes: horizontal lockup 96 px wide, stacked 64 px, icon 24 px.
  Below 24 px, use the favicon files. They are drawn for that size.


PLEASE DON'T

  Recolor, outline, stretch, squash or rotate the logo. Add shadows, glows
  or gradients. Put the full-color icon on teal. Retype the wordmark in a
  font. Use retired marks or the product's former name. If it isn't in this
  kit, it isn't the logo.


The name is Blowhorn: one word, capital B. Blowhorn and the Blowhorn logos
are marks of Layer5, Inc. This kit lets you refer to Blowhorn; it doesn't
grant a license to use the marks in your own product names or logos.
